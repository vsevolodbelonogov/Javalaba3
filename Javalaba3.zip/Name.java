/**
 * Immutable Name: any of the three fields may be null/empty,
 * but at least one must be non-null and non-empty.
 */
public final class Name {
    private final String firstName;
    private final String lastName;
    private final String patronymic;

    public Name(String firstName) {
        this(firstName, null, null);
    }

    public Name(String firstName, String lastName) {
        this(firstName, lastName, null);
    }

    public Name(String firstName, String lastName, String patronymic) {
        if (isNullOrEmpty(firstName) && isNullOrEmpty(lastName) && isNullOrEmpty(patronymic)) {
            throw new IllegalArgumentException("At least one name component must be non-empty");
        }
        this.firstName = normalize(firstName);
        this.lastName = normalize(lastName);
        this.patronymic = normalize(patronymic);
    }

    private static boolean isNullOrEmpty(String s) {
        return s == null || s.trim().isEmpty();
    }

    private static String normalize(String s) {
        return s == null ? null : s.trim();
    }

    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getPatronymic() { return patronymic; }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (firstName != null) sb.append(firstName);
        if (patronymic != null) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(patronymic);
        }
        if (lastName != null) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(lastName);
        }
        return sb.toString();
    }

    /**
     * Return a new Name with missing components filled from provided values (may be null).
     */
    public Name withFilled(String fillFirst, String fillLast, String fillPatronymic) {
        String f = this.firstName != null ? this.firstName : normalize(fillFirst);
        String l = this.lastName != null ? this.lastName : normalize(fillLast);
        String p = this.patronymic != null ? this.patronymic : normalize(fillPatronymic);
        return new Name(f, l, p);
    }
}
