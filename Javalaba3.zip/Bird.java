/**
 * Abstract bird base class
 */
public abstract class Bird {
    public abstract void sing();
}
