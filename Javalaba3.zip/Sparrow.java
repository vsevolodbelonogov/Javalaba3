public class Sparrow extends Bird {
    @Override
    public void sing() {
        System.out.println("чырык");
    }
}
