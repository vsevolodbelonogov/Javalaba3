import static java.lang.Integer.parseInt;
import static java.lang.Math.pow;

/**
 * Utility for power: uses Integer.parseInt and Math.pow (static imports used)
 */
public class MathUtils {
    public static double power(String x, String y) {
        try {
            int base = parseInt(x.trim());
            int exp = parseInt(y.trim());
            return pow(base, exp);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Both parameters must be integers");
        }
    }
}
