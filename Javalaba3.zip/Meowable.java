/**
 * Interface for objects that can meow.
 */
public interface Meowable {
    void meow();
}
