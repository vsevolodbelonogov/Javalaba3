import java.util.Random;

public class Parrot extends Bird {
    private final String phrase;
    private static final Random RNG = new Random();

    public Parrot(String phrase) {
        if (phrase == null || phrase.trim().isEmpty()) {
            throw new IllegalArgumentException("Parrot must have a non-empty phrase");
        }
        this.phrase = phrase;
    }

    @Override
    public void sing() {
        int n = 1 + RNG.nextInt(phrase.length());
        System.out.println(phrase.substring(0, n));
    }
}
