import java.util.Scanner;

/**
 * Точка входа. Демонстрирует работу всех классов.
 * Все исходные данные вводятся с клавиатуры с валидацией.
 */
public class Main {
    private static final Scanner SC = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=== ЛР3: Демонстрация блоков 1-6 ===");
        demoNamesAndPeople();
        demoSecrets();
        demoPoints();
        demoBirds();
        demoMeow();
        demoMathUtils();
        System.out.println("=== Готово ===");
    }

    private static String readNonEmpty(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = SC.nextLine();
            if (s != null && !s.trim().isEmpty()) return s.trim();
            System.out.println("Ошибка: ввод не может быть пустым. Попробуйте ещё раз.");
        }
    }

    private static int readIntInRange(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String s = SC.nextLine();
            try {
                int v = Integer.parseInt(s.trim());
                if (v < min || v > max) {
                    System.out.println("Ошибка: число должно быть в диапазоне " + min + "–" + max);
                    continue;
                }
                return v;
            } catch (Exception e) {
                System.out.println("Ошибка: введите целое число.");
            }
        }
    }

    private static void demoNamesAndPeople() {
        System.out.println("\n--- Блок 1: Name и Person ---");
        System.out.println("Создадим имена (по условию примеры):");

        // Создаём по примеру — но читаем из клавиатуры (если пусто — используем предложенные значения)
        System.out.println("Введите имя для примера 1 (по умолчанию 'Клеопатра'):");
        String in1 = SC.nextLine().trim();
        if (in1.isEmpty()) in1 = "Клеопатра";
        Name n1 = new Name(in1);

        System.out.println("Введите три части имени для примера 2 через enter (по умолчанию 'Александр','Пушкин','Сергеевич'):");
        System.out.print("Личное: ");
        String aFirst = SC.nextLine().trim();
        if (aFirst.isEmpty()) aFirst = "Александр";
        System.out.print("Фамилия: ");
        String aLast = SC.nextLine().trim();
        if (aLast.isEmpty()) aLast = "Пушкин";
        System.out.print("Отчество: ");
        String aPat = SC.nextLine().trim();
        if (aPat.isEmpty()) aPat = "Сергеевич";
        Name n2 = new Name(aFirst, aLast, aPat);

        System.out.println("Введите имя и фамилию для примера 3 (по умолчанию 'Владимир','Маяковский'):");
        System.out.print("Личное: ");
        String vFirst = SC.nextLine().trim();
        if (vFirst.isEmpty()) vFirst = "Владимир";
        System.out.print("Фамилия: ");
        String vLast = SC.nextLine().trim();
        if (vLast.isEmpty()) vLast = "Маяковский";
        Name n3 = new Name(vFirst, vLast);

        System.out.println("Пример 4: Христофор Бонифатьевич (имя и фамилия).");
        Name n4 = new Name("Христофор", "Бонифатьевич");

        System.out.println("Список созданных имён:");
        System.out.println(n1);
        System.out.println(n2);
        System.out.println(n3);
        System.out.println(n4);

        System.out.println("\nСоздадим людей по сценарию:");
        Person p1 = new Person("Лев", 170); // 1
        System.out.println("Создан человек: " + p1);

        // 2: Пушкин Сергей (как Name), рост 168 и отец Лев
        Person p2 = new Person(new Name("Сергей", "Пушкин"), 168, p1);
        System.out.println("Создан человек: " + p2);

        // 3: Александр (как строка), рост 167, отец Сергей
        Person p3 = new Person("Александр", 167, p2);
        System.out.println("Создан человек: " + p3);

        System.out.println("Проверка изменения роста (меняем рост Льва на ввод).");
        int newHeight = readIntInRange("Введите новый рост для Льва (1–500): ", 1, 500);
        p1.setHeight(newHeight);
        System.out.println("Лев теперь: " + p1);
    }

    private static void demoSecrets() {
        System.out.println("\n--- Блок 2: Secret ---");
        System.out.println("Создаём начальный секрет.");
        String owner = readNonEmpty("Введите имя первого хранителя: ");
        String text = readNonEmpty("Введите текст секрета: ");
        Secret s1 = new Secret(owner, text);

        System.out.println("Передаём секрет следующему (имя вводится):");
        String owner2 = readNonEmpty("Имя следующего хранителя: ");
        Secret s2 = new Secret(s1, owner2);

        System.out.println("Передаём ещё раз:");
        String owner3 = readNonEmpty("Имя третьего хранителя: ");
        Secret s3 = new Secret(s2, owner3);

        System.out.println("Текущее представление: " + s3);
        System.out.println("Порядок s2: " + s2.getOrder());
        System.out.println("Сколько людей узнали после s2: " + s2.howManyLearnedAfter());
        System.out.println("Имя +1 от s1: " + s1.getNthHolderName(1));
        System.out.println("Разница в длине s1 и s3: " + s1.diffInLengthWithNth(2));
    }

    private static void demoPoints() {
        System.out.println("\n--- Блок 3: Point2D и Point3D ---");
        int x1 = readIntInRange("Введите X для точки 1 (целое): ", -10000, 10000);
        int y1 = readIntInRange("Введите Y для точки 1 (целое): ", -10000, 10000);
        Point2D p1 = new Point2D(x1, y1);

        int x2 = readIntInRange("Введите X для точки 2 (целое): ", -10000, 10000);
        int y2 = readIntInRange("Введите Y для точки 2 (целое): ", -10000, 10000);
        Point2D p2 = new Point2D(x2, y2);

        int x3 = readIntInRange("Введите X для 3D точки (целое): ", -10000, 10000);
        int y3 = readIntInRange("Введите Y для 3D точки (целое): ", -10000, 10000);
        int z3 = readIntInRange("Введите Z для 3D точки (целое): ", -10000, 10000);
        Point3D p3 = new Point3D(x3, y3, z3);

        System.out.println("Точка1: " + p1);
        System.out.println("Точка2: " + p2);
        System.out.println("Точка3: " + p3);
        System.out.println("Клон 3D: " + p3.clone());
    }

    private static void demoBirds() {
        System.out.println("\n--- Блок 4: Птицы ---");
        Bird s = new Sparrow();
        Bird c = new Cuckoo();
        System.out.print("Воробей: ");
        s.sing();
        System.out.print("Кукушка: ");
        c.sing();

        String phrase = readNonEmpty("Введите фразу для попугая: ");
        Bird p = new Parrot(phrase);
        System.out.print("Попугай: ");
        p.sing();
    }

    private static void demoMeow() {
        System.out.println("\n--- Блок 5: Мяуканье ---");
        String name1 = readNonEmpty("Имя первого кота: ");
        String name2 = readNonEmpty("Имя второго кота: ");
        Cat cat1 = new Cat(name1);
        Cat cat2 = new Cat(name2);
        System.out.println("Вызываем утилиту makeAllMeow:");
        MeowUtils.makeAllMeow(cat1, cat2);

        // дополнительная проверка: можно передать другой класс, реализующий Meowable
        System.out.println("Создадим игрушку, реализующую Meowable:");
        ToyMeower toy = new ToyMeower("T-01");
        MeowUtils.makeAllMeow(toy);
    }

    private static void demoMathUtils() {
        System.out.println("\n--- Блок 6: MathUtils (возведение в степень) ---");
        String sx = readNonEmpty("Введите целое X: ");
        String sy = readNonEmpty("Введите целое Y: ");
        double res;
        try {
            res = MathUtils.power(sx, sy);
            System.out.println(sx + "^" + sy + " = " + res);
        } catch (IllegalArgumentException e) {
            System.out.println("Ошибка при вычислении степени: " + e.getMessage());
        }
    }
}
