import java.util.Random;

/**
 * Secret allows storing a text and passing it to exactly one other holder.
 * Only way to see text is printing during initialization.
 */
public class Secret {
    private final String holderName;
    private final String text;
    private final Secret previous;
    private Secret next;
    private static final Random RNG = new Random();

    // Create new secret (initial)
    public Secret(String holderName, String text) {
        if (holderName == null || holderName.trim().isEmpty())
            throw new IllegalArgumentException("holderName must be non-empty");
        if (text == null)
            throw new IllegalArgumentException("text must not be null");
        this.holderName = holderName.trim();
        this.text = text;
        this.previous = null;
        this.next = null;
        System.out.println(this.holderName + " получил секрет: " + this.text);
    }

    // Transfer constructor: tell secret to newHolder
    public Secret(Secret from, String newHolderName) {
        if (from == null) throw new IllegalArgumentException("from must not be null");
        if (from.next != null) throw new IllegalStateException("This secret was already passed further");
        if (newHolderName == null || newHolderName.trim().isEmpty())
            throw new IllegalArgumentException("newHolderName must be non-empty");
        // Print telling message
        System.out.println(from.holderName + " сказал что " + from.text);
        this.previous = from;
        from.next = this;
        this.holderName = newHolderName.trim();
        this.text = mutateText(from.text);
        this.next = null;
        System.out.println(this.holderName + " получил секрет: " + this.text);
    }

    private String mutateText(String base) {
        int n = (int) Math.floor(0.1 * base.length());
        if (n < 0) n = 0;
        int x = (n == 0) ? 0 : RNG.nextInt(n + 1); // 0..n
        StringBuilder sb = new StringBuilder(base);
        for (int i = 0; i < x; i++) {
            int pos = sb.length() == 0 ? 0 : RNG.nextInt(sb.length() + 1);
            char c = (char) ('!' + RNG.nextInt(94)); // printable chars
            sb.insert(pos, c);
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return holderName + ": это секрет!";
    }

    // 1-based order: initial secret has order 1
    public int getOrder() {
        int k = 1;
        Secret cur = this;
        while (cur.previous != null) { k++; cur = cur.previous; }
        return k;
    }

    // how many learned after current
    public int howManyLearnedAfter() {
        int cnt = 0;
        Secret cur = this.next;
        while (cur != null) { cnt++; cur = cur.next; }
        return cnt;
    }

    /**
     * Get name of N-th holder relative to this.
     * n>0 => forward (next), n<0 => backward (previous)
     */
    public String getNthHolderName(int n) {
        if (n == 0) return holderName;
        Secret cur = this;
        if (n > 0) {
            for (int i = 0; i < n; i++) {
                if (cur.next == null) throw new IllegalArgumentException("No such next holder");
                cur = cur.next;
            }
        } else {
            for (int i = 0; i < -n; i++) {
                if (cur.previous == null) throw new IllegalArgumentException("No such previous holder");
                cur = cur.previous;
            }
        }
        return cur.holderName;
    }

    // difference in length with N-th holder
    public int diffInLengthWithNth(int n) {
        Secret other = getRelative(n);
        return this.text.length() - other.text.length();
    }

    private Secret getRelative(int n) {
        if (n == 0) return this;
        Secret cur = this;
        if (n > 0) {
            for (int i = 0; i < n; i++) {
                if (cur.next == null) throw new IllegalArgumentException("No such next holder");
                cur = cur.next;
            }
        } else {
            for (int i = 0; i < -n; i++) {
                if (cur.previous == null) throw new IllegalArgumentException("No such previous holder");
                cur = cur.previous;
            }
        }
        return cur;
    }
}
