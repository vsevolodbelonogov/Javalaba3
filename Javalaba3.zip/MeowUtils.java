/**
 * Utility to call meow() on multiple Meowable objects.
 */
public class MeowUtils {
    public static void makeAllMeow(Meowable... meowers) {
        if (meowers == null) return;
        for (Meowable m : meowers) {
            if (m != null) m.meow();
        }
    }
}
