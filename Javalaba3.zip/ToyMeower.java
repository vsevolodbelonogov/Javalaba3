/**
 * Простейшая "игрушка", реализующая Meowable.
 * Должна лежать в src/ рядом с другими файлами (без package).
 */
public class ToyMeower implements Meowable {
    private final String id;

    public ToyMeower(String id) {
        this.id = (id == null || id.trim().isEmpty()) ? "toy" : id.trim();
    }

    @Override
    public void meow() {
        System.out.println("Toy#" + id + ": fake-meow");
    }

    @Override
    public String toString() {
        return "ToyMeower(" + id + ")";
    }
}
