public class Cat implements Meowable {
    private final String name;

    public Cat(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Cat name must be non-empty");
        }
        this.name = name.trim();
    }

    @Override
    public void meow() {
        System.out.println(name + ": мяу");
    }

    @Override
    public String toString() {
        return "Cat(" + name + ")";
    }
}
