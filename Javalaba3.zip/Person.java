/**
 * Person:
 * - name (Name) accessible via getName()
 * - height: positive and <= 500, mutable via setHeight()
 * - father: final, set only at construction
 *
 * Multiple constructors as required; all assignment occurs in the single private constructor.
 */
public class Person {
    private Name name;
    private int height;
    private final Person father;

    // Central constructor - the only one that assigns fields directly.
    private Person(Name name, int height, Person father, boolean internal) {
        if (name == null) throw new IllegalArgumentException("Name must not be null");
        setHeightInternal(height);
        this.father = father;
        this.name = name;
    }

    // Public constructors delegate to central one.
    public Person(String firstName, int height) {
        this(new Name(firstName), height, null, true);
    }

    public Person(Name name, int height) {
        this(name, height, null, true);
    }

    public Person(String firstName, int height, Person father) {
        // name as string => only first name
        Name provided = new Name(firstName);
        if (father != null) {
            // fill patronymic and surname from father
            String pat = makePatronymicFromFather(father.getName());
            String last = father.getName().getLastName();
            provided = new Name(provided.getFirstName(), last, pat);
        }
        this(provided, height, father, true);
    }

    public Person(Name nameObj, int height, Person father) {
        Name finalName = nameObj;
        if (father != null) {
            // if nameObj misses patronymic or last name, fill them
            String fillPat = nameObj.getPatronymic() == null ? makePatronymicFromFather(father.getName()) : nameObj.getPatronymic();
            String fillLast = nameObj.getLastName() == null ? father.getName().getLastName() : nameObj.getLastName();
            finalName = new Name(nameObj.getFirstName(), fillLast, fillPat);
        }
        this(finalName, height, father, true);
    }

    private static String makePatronymicFromFather(Name fatherName) {
        if (fatherName == null || fatherName.getFirstName() == null) {
            throw new IllegalArgumentException("Father's first name required to generate patronymic");
        }
        String f = fatherName.getFirstName().trim();
        if (f.isEmpty()) throw new IllegalArgumentException("Father's first name required");
        // Simple heuristic: just add "ович" (this is acceptable for the task; can be improved).
        return f + "ович";
    }

    private void setHeightInternal(int h) {
        if (h <= 0 || h > 500) throw new IllegalArgumentException("Height must be in range 1..500");
        this.height = h;
    }

    public Name getName() { return name; }

    public int getHeight() { return height; }

    public void setHeight(int height) {
        setHeightInternal(height);
    }

    public Person getFather() { return father; }

    @Override
    public String toString() {
        return String.format("%s, %d", name.toString(), height);
    }
}
