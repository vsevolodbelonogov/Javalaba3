import java.util.Random;

public class Cuckoo extends Bird {
    private static final Random RNG = new Random();

    @Override
    public void sing() {
        int times = 1 + RNG.nextInt(10);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < times; i++) {
            if (i > 0) sb.append(' ');
            sb.append("ку-ку");
        }
        System.out.println(sb.toString());
    }
}
